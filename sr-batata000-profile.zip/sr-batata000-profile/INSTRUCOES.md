# Como publicar o perfil

Este projeto é o README de perfil do GitHub do usuário **sr-batata000**. Todas as imagens principais (banner, rodapé, ícones, badges e divisores) são arquivos SVG locais na pasta `assets/`, carregados por caminhos relativos (`./assets/...`).

## 1. Crie o repositório especial

O GitHub só mostra o README no seu perfil se o repositório tiver **exatamente o mesmo nome do usuário**:

1. Acesse https://github.com/new
2. Em **Repository name**, digite `sr-batata000`
3. Marque **Public**
4. Marque **Add a README file** apenas se quiser; vamos substituí-lo de qualquer forma
5. Clique em **Create repository**

## 2. Envie os arquivos

Atenção: envie o **conteúdo** da pasta `sr-batata000-profile`, não a pasta em si. O `README.md` precisa ficar na raiz do repositório e a pasta `assets/` ao lado dele.

### Opção A: pelo navegador

1. Descompacte o ZIP.
2. No repositório, clique em **Add file → Upload files**.
3. Arraste `README.md`, `INSTRUCOES.md` e a pasta `assets` inteira.
4. Clique em **Commit changes**.

### Opção B: pelo terminal

```bash
cd sr-batata000-profile
git init
git add .
git commit -m "Adiciona perfil"
git branch -M main
git remote add origin https://github.com/sr-batata000/sr-batata000.git
git push -u origin main
```

Se o repositório já tiver um README criado pelo GitHub, use `git pull origin main --allow-unrelated-histories` antes do push, ou `git push -f origin main` para substituir.

## 3. Configure o Instagram

Abra o `README.md` e procure por `SEU_USUARIO`:

```html
<a href="https://www.instagram.com/SEU_USUARIO/">
```

Troque pelo seu usuário. Se preferir não exibir o Instagram por enquanto, apague a tag `<a>` inteira desse badge.

## 4. Estatísticas

As estatísticas usam serviços externos gratuitos (GitHub Readme Stats e Streak Stats). Eles mostram dados reais da sua conta: em uma conta nova, os números começam baixos ou zerados, e isso é normal. Os serviços às vezes ficam instáveis e o GitHub guarda as imagens em cache por algum tempo.

Se alguma imagem de estatística aparecer quebrada:

- Aguarde alguns minutos e atualize a página.
- Ou use a alternativa local: no `README.md`, troque o `src` da imagem quebrada por `./assets/stats-fallback.svg` (card sem números, apenas com o link do perfil).
- Ou apague o bloco `<p align="center">` da imagem em questão.

## 5. Confira o resultado

Abra https://github.com/sr-batata000. O README aparece acima das abas do perfil. Se alguma imagem local não carregar:

- Confirme que o repositório é **público**.
- Confirme que `assets/` está na raiz, ao lado do `README.md`.
- Os nomes de arquivo diferenciam maiúsculas de minúsculas no GitHub: mantenha tudo em minúsculas.

## Estrutura

```
sr-batata000-profile/
├── README.md
├── INSTRUCOES.md
└── assets/
    ├── header.svg, footer.svg, divider.svg
    ├── html5.svg, css3.svg, javascript.svg, python.svg
    ├── git.svg, github.svg, vscode.svg, markdown.svg
    ├── instagram.svg
    ├── badge-github.svg, badge-instagram.svg
    └── stats-fallback.svg
```

## Observações

- Os ícones de tecnologia são versões simplificadas, desenhadas para manter a identidade visual do perfil. Se quiser os logotipos oficiais, basta substituir os arquivos em `assets/` mantendo os mesmos nomes.
- Não há seção de projetos, conforme combinado. Quando tiver projetos, adicione uma nova seção antes de **GitHub Statistics**.
